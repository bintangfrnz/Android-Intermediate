package com.bintangfajarianto.submission1

import android.app.Application

class BaseApplication : Application()